<?php

$db_name = 'mysql:host=localhost;dbname=food_db';
$user_name = 'admin1';
$user_password = 'admin1';

$conn = new PDO($db_name, $user_name, $user_password);

?>